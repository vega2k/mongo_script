package mymongo;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

public class ConnectToDB {

	public static void main(String args[]) {

		// Creating a Mongo client
		MongoClient mongo = new MongoClient("localhost", 27017);
		System.out.println("MongoClient " + mongo);

		// Accessing the database
		MongoDatabase database = mongo.getDatabase("myDb");
		System.out.println("Mongo DB " + database);
		System.out.println("Connected to the DB successfully");

		// Creating a collection
		database.createCollection("sampleCollection");
		System.out.println("Collection created successfully");

		mongo.close();
	}
}
